import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import cmcrameri as cm



